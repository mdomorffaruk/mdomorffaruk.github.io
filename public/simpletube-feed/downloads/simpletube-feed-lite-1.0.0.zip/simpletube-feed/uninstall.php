<?php
/**
 * Uninstall handler.
 *
 * Runs only when the plugin is deleted from the WordPress admin. Removes
 * plugin options and transient caches. No settings are left behind.
 *
 * @package SimpleTubeFeed
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Remove main options.
delete_option( 'stf_settings' );

// Remove all plugin transients.
global $wpdb;
$prefix = 'stf_cache_';
$like   = $wpdb->esc_like( '_transient_' . $prefix ) . '%';
$like_t = $wpdb->esc_like( '_transient_timeout_' . $prefix ) . '%';

// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		$like,
		$like_t
	)
);
