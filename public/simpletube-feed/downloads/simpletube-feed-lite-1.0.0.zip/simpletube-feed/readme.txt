=== SimpleTube Feed Lite ===
Contributors: mdomorffaruk
Tags: youtube, youtube channel, video, feed, rss, shortcode, block
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Display a clean, lightweight YouTube channel feed on WordPress using the official public RSS feed. No API key required.

== Description ==

SimpleTube Feed Lite shows the latest videos from any YouTube channel directly on your WordPress site — fast, clean, and free from the bloat of larger social-feed plugins.

It uses YouTube's **official, public RSS feed**, so **no API key is required** and there are no recurring subscription costs. No scraping, no heavy scripts, no external accounts, no tracking, and no advertising.

= Key features =

* **Official YouTube channel RSS** — no API key needed.
* **Responsive grid** and **list** layouts.
* **Shortcode** — `[simpletube_feed channel="CHANNEL_ID" limit="6"]`.
* **Gutenberg block** — insert and configure the feed visually.
* **Configurable** number of videos, titles, dates, and new-tab behavior.
* **Smart caching** to keep your site fast without hammering YouTube.
* **Graceful fallback** when a channel is unavailable or a feed is empty.
* **Accessible, mobile-first** markup.
* **No advertising, no tracking, no external accounts, no license server.**

= How it works =

1. Install and activate the plugin.
2. Add your YouTube channel ID on the Settings → SimpleTube Feed page.
3. Add the block or shortcode to any post or page.

To find a channel ID, open the channel on YouTube and look at the URL: `youtube.com/channel/CHANNEL_ID`.

= Privacy =

The plugin fetches the public RSS feed from YouTube directly from your server using WordPress's HTTP API. No analytics, no cookies, no data sent to third parties, and no external accounts. Your visitors' data is never collected or transmitted to any SimpleTube server.

== Installation ==

1. Upload the `simpletube-feed` folder to `/wp-content/plugins/`, or install the ZIP via Plugins → Add New → Upload Plugin.
2. Activate the plugin through the Plugins menu.
3. Go to Settings → SimpleTube Feed and enter your YouTube channel ID.
4. Add the block or the shortcode to any post, page, or widget.

== Frequently Asked Questions ==

= Do I need a YouTube API key? =

No. SimpleTube Feed Lite uses YouTube's public RSS feed and works without any API key.

= Where do I find my channel ID? =

Open your channel on YouTube. The URL looks like `youtube.com/channel/UCxxxxxxxxxxxxxxxxxxxxxx`. The part after `/channel/` is your channel ID.

= How do I display the feed? =

Add the Gutenberg **SimpleTube Feed** block, or use the shortcode:

`[simpletube_feed channel="CHANNEL_ID" limit="6"]`

= Can I change the number of videos? =

Yes. Use the `limit` attribute or the block/settings controls (1–50).

= Why is there a short delay before new videos appear? =

Feeds are cached to keep your site fast. The cache refreshes automatically. You can clear it anytime from the plugin settings page.

= Is this compatible with my theme? =

Yes. The feed uses simple styles that inherit your theme's colors and adapt to any screen size. Advanced styling controls are available in SimpleTube Feed Pro.

== Screenshots ==

1. Grid layout of a YouTube channel feed.
2. List layout of a YouTube channel feed.
3. The settings page.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
* Initial release.
