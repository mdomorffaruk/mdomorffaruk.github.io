/**
 * SimpleTube Feed Lite - Gutenberg block editor script.
 *
 * Loaded only in the block editor. Registers a dynamic block whose markup
 * is rendered server-side. No feed data is exposed here.
 *
 * @package SimpleTubeFeed
 */

(function (wp) {
	const { registerBlockType } = wp.blocks;
	const { __ } = wp.i18n;
	const {
		InspectorControls,
		useBlockProps,
	} = wp.blockEditor;
	const {
		PanelBody,
		TextControl,
		RangeControl,
		SelectControl,
		Placeholder,
	} = wp.components;
	const { createElement } = wp.element;

	registerBlockType('simpletube/feed', {
		apiVersion: 2,
		title: __('SimpleTube Feed', 'simpletube-feed'),
		description: __('Display a lightweight YouTube channel feed.', 'simpletube-feed'),
		icon: 'video-alt3',
		category: 'embed',
		keywords: [__('YouTube', 'simpletube-feed'), __('video', 'simpletube-feed'), __('feed', 'simpletube-feed')],
		attributes: {
			channel: { type: 'string', default: '' },
			limit: { type: 'number', default: 6 },
			layout: { type: 'string', default: 'grid' },
			heading: { type: 'string', default: '' },
		},

		edit: function (props) {
			const blockProps = useBlockProps();
			const { attributes, setAttributes } = props;

			const controls = createElement(InspectorControls, { key: 'controls' },
				createElement(PanelBody, { title: __('Feed Settings', 'simpletube-feed'), initialOpen: true },
					createElement(TextControl, {
						label: __('YouTube Channel ID', 'simpletube-feed'),
						value: attributes.channel,
						onChange: function (value) {
							// Strip disallowed characters immediately.
							setAttributes({ channel: value.replace(/[^A-Za-z0-9_\-]/g, '') });
						},
						help: __('From youtube.com/channel/CHANNEL_ID', 'simpletube-feed'),
					}),
					createElement(RangeControl, {
						label: __('Number of videos', 'simpletube-feed'),
						value: attributes.limit,
						onChange: function (value) {
							setAttributes({ limit: Math.max(1, Math.min(50, value)) });
						},
						min: 1,
						max: 50,
					}),
					createElement(SelectControl, {
						label: __('Layout', 'simpletube-feed'),
						value: attributes.layout,
						options: [
							{ label: __('Grid', 'simpletube-feed'), value: 'grid' },
							{ label: __('List', 'simpletube-feed'), value: 'list' },
						],
						onChange: function (value) {
							setAttributes({ layout: value });
						},
					}),
					createElement(TextControl, {
						label: __('Optional heading', 'simpletube-feed'),
						value: attributes.heading,
						onChange: function (value) {
							setAttributes({ heading: value });
						},
					})
				)
			);

			const body = createElement(Placeholder, { key: 'body', icon: 'video-alt3', label: __('SimpleTube Feed', 'simpletube-feed') },
				createElement('p', null, attributes.channel
					? __('This block will show the latest videos from the configured channel.', 'simpletube-feed')
					: __('Add a YouTube channel ID to display your feed.', 'simpletube-feed'))
			);

			return createElement('div', blockProps, controls, body);
		},

		save: function () {
			// Dynamic block - markup is rendered server-side.
			return null;
		},
	});
})(window.wp);
