<?php
/**
 * Frontend renderer.
 *
 * Produces accessible, responsive, safely-escaped markup for the feed.
 * Supports grid and list layouts. Never outputs unescaped data.
 *
 * @package SimpleTubeFeed
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * STF_Renderer
 */
class STF_Renderer {

	/**
	 * Cache instance.
	 *
	 * @var STF_Cache
	 */
	protected $cache;

	/**
	 * Constructor.
	 *
	 * @param STF_Cache $cache Cache instance.
	 */
	public function __construct( STF_Cache $cache ) {
		$this->cache = $cache;
	}

	/**
	 * Enqueue frontend stylesheet.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		if ( wp_style_is( 'stf-frontend', 'enqueued' ) || wp_style_is( 'stf-frontend', 'registered' ) ) {
			return;
		}
		wp_register_style( 'stf-frontend', STF_PLUGIN_URL . 'assets/css/stf-frontend.css', array(), STF_VERSION );
		wp_enqueue_style( 'stf-frontend' );
	}

	/**
	 * Compute resolved layout.
	 *
	 * @param array $args Shortcode/settings args.
	 * @return string 'grid' or 'list'
	 */
	public function resolved_layout( $args ) {
		$layout = isset( $args['layout'] ) ? strtolower( (string) $args['layout'] ) : 'grid';
		return in_array( $layout, array( 'grid', 'list' ), true ) ? $layout : 'grid';
	}

	/**
	 * Render a feed (with caching + graceful fallback).
	 *
	 * @param array $args Normalized arguments.
	 * @return string HTML.
	 */
	public function render( $args ) {
		$this->enqueue_assets();

		$channel = isset( $args['channel'] ) ? trim( (string) $args['channel'] ) : '';

		if ( '' === $channel ) {
			return $this->render_error( __( 'No YouTube channel id provided.', 'simpletube-feed' ) );
		}

		$limit  = isset( $args['limit'] ) ? max( 1, min( 50, (int) $args['limit'] ) ) : 6;
		$layout = $this->resolved_layout( $args );
		$ttl    = isset( $args['cache_ttl'] ) ? max( 60, (int) $args['cache_ttl'] ) : STF_Cache::DEFAULT_TTL;

		$cache_key  = $this->cache->feed_key( array( 'channel' => $channel, 'limit' => $limit ) );
		$cached     = $this->cache->get( $cache_key );

		if ( false !== $cached && is_array( $cached ) ) {
			return $this->render_items( $cached, $args, $layout );
		}

		$parser = STF_Plugin::instance()->get_module( 'parser' );
		$result = $parser->fetch( $channel, $limit );

		if ( is_wp_error( $result ) ) {
			return $this->render_error( $result->get_error_message() );
		}

		if ( empty( $result ) ) {
			return $this->render_error( __( 'No videos were found for this channel.', 'simpletube-feed' ) );
		}

		// Cache the successful result. If caching is disabled, skip.
		if ( empty( $args['no_cache'] ) ) {
			$this->cache->set( $cache_key, $result, $ttl );
		}

		return $this->render_items( $result, $args, $layout );
	}

	/**
	 * Render a list of items.
	 *
	 * @param array  $items  Sanitized feed items.
	 * @param array  $args   Render options.
	 * @param string $layout Layout name.
	 * @return string
	 */
	protected function render_items( $items, $args, $layout ) {
		$show_title = ! empty( $args['show_title'] );
		$show_date  = ! empty( $args['show_date'] );
		$new_tab    = ! empty( $args['new_tab'] );
		$rel_attr   = $new_tab ? ' target="_blank" rel="noopener noreferrer"' : '';

		$wrapper_class = 'stf-feed stf-feed--' . $layout;
		$heading       = isset( $args['heading'] ) ? sanitize_text_field( (string) $args['heading'] ) : '';

		$out  = '<div class="' . esc_attr( $wrapper_class ) . '" data-stf-count="' . esc_attr( (string) count( $items ) ) . '">';
		if ( '' !== $heading ) {
			$out .= '<h2 class="stf-heading">' . esc_html( $heading ) . '</h2>';
		}

		if ( 'list' === $layout ) {
			$out .= '<ol class="stf-list">';
		} else {
			$out .= '<div class="stf-grid" role="list">';
		}

		foreach ( $items as $item ) {
			$out .= $this->render_item( $item, $args, $layout, $new_tab, $rel_attr, $show_title, $show_date );
		}

		if ( 'list' === $layout ) {
			$out .= '</ol>';
		} else {
			$out .= '</div>';
		}
		$out .= '</div>';

		return $out;
	}

	/**
	 * Render a single item.
	 *
	 * @param array  $item       Sanitized item.
	 * @param array  $args       Render options.
	 * @param string $layout     Layout.
	 * @param bool   $new_tab    Open links in new tab.
	 * @param string $rel_attr   Precomputed rel attribute.
	 * @param bool   $show_title Show title.
	 * @param bool   $show_date  Show date.
	 * @return string
	 */
	protected function render_item( $item, $args, $layout, $new_tab, $rel_attr, $show_title, $show_date ) {
		$link       = isset( $item['link'] ) ? $item['link'] : '';
		$thumb      = isset( $item['thumbnail'] ) ? $item['thumbnail'] : '';
		$title      = isset( $item['title'] ) ? $item['title'] : '';
		$date       = isset( $item['date'] ) ? (int) $item['date'] : 0;
		$video_id   = isset( $item['video_id'] ) ? $item['video_id'] : '';

		$tag  = ( 'list' === $layout ) ? 'li' : 'div';
		$href = ( '' !== $link ) ? $link : '#';

		$out = '<' . $tag . ' class="stf-item">';
		$out .= '<a class="stf-item__link" href="' . esc_url( $href ) . '"' . $rel_attr . '>';
		$out .= '<span class="stf-thumb">';
		if ( '' !== $thumb ) {
			$out .= '<img class="stf-thumb__img" src="' . esc_url( $thumb ) . '" alt="' . esc_attr( $title ) . '" loading="lazy" width="480" height="360">';
		} else {
			// Play icon fallback shown via CSS using the video id as a data attr.
			$out .= '<span class="stf-thumb__placeholder" data-vid="' . esc_attr( $video_id ) . '" aria-hidden="true"></span>';
		}
		$out .= '</span>';
		if ( $show_title ) {
			$out .= '<span class="stf-title">' . esc_html( $title ) . '</span>';
		}
		if ( $show_date && $date > 0 ) {
			$out .= '<span class="stf-date">' . esc_html( $this->format_date( $date ) ) . '</span>';
		}
		$out .= '</a>';
		$out .= '</' . $tag . '>';

		return $out;
	}

	/**
	 * Format a timestamp for display.
	 *
	 * @param int $timestamp Unix timestamp.
	 * @return string
	 */
	public function format_date( $timestamp ) {
		$format = get_option( 'date_format', 'M j, Y' );
		return date_i18n( $format, $timestamp );
	}

	/**
	 * Render a friendly error / fallback state.
	 *
	 * Public so companion plugins (Pro) can reuse the shared error UI.
	 *
	 * @param string $message Sanitized message.
	 * @return string
	 */
	public function render_error( $message ) {
		return '<div class="stf-feed stf-feed--error" role="status"><p class="stf-error">'
			. esc_html( $message )
			. '</p></div>';
	}
}
