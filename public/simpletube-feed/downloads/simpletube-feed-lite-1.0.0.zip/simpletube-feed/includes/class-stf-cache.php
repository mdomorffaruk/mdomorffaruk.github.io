<?php
/**
 * Transient-based caching wrapper.
 *
 * Wraps WordPress transients with a unique prefix, grouped TTLs, and a
 * central place to flush all of the plugin's cached feeds.
 *
 * @package SimpleTubeFeed
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * STF_Cache
 */
class STF_Cache {

	/**
	 * Default cache lifetime in seconds (12 hours).
	 *
	 * @var int
	 */
	const DEFAULT_TTL = 43200;

	/**
	 * Build a namespaced cache key.
	 *
	 * @param string $key Base key.
	 * @return string
	 */
	public function key( $key ) {
		return STF_OPTION_PREFIX . 'cache_' . md5( (string) $key );
	}

	/**
	 * Get a cached value.
	 *
	 * @param string $key Cache key.
	 * @return mixed False on miss, stored value on hit.
	 */
	public function get( $key ) {
		return get_transient( $this->key( $key ) );
	}

	/**
	 * Store a value in cache.
	 *
	 * @param string $key     Cache key.
	 * @param mixed  $value   Value to store.
	 * @param int    $ttl     Lifetime in seconds.
	 * @return bool
	 */
	public function set( $key, $value, $ttl = self::DEFAULT_TTL ) {
		$ttl = max( 60, (int) $ttl );
		return set_transient( $this->key( $key ), $value, $ttl );
	}

	/**
	 * Delete a single cached value.
	 *
	 * @param string $key Cache key.
	 * @return bool
	 */
	public function delete( $key ) {
		return delete_transient( $this->key( $key ) );
	}

	/**
	 * Compute a cache key for a feed request.
	 *
	 * @param array $args Normalized feed arguments.
	 * @return string
	 */
	public function feed_key( $args ) {
		return 'feed_' . md5( wp_json_encode( $this->normalize( $args ) ) );
	}

	/**
	 * Clear the transient cache by deleting all plugin-owned transients.
	 *
	 * Because transient lookups by prefix are not built into core, we walk
	 * the options table. Falls back gracefully if the DB row is unavailable.
	 *
	 * @return int Number of transients deleted.
	 */
	public function clear_all() {
		global $wpdb;

		if ( ! $wpdb || ! isset( $wpdb->options ) ) {
			return 0;
		}

		$prefix = STF_OPTION_PREFIX . 'cache_';
		$like   = $wpdb->esc_like( $prefix ) . '%';
		// Prefix matches: _transient_<key> and _transient_timeout_<key>.
		$sql = $wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			'_transient_' . $like,
			'_transient_timeout_' . $like
		);

		return (int) $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Normalize feed arguments for deterministic cache keys.
	 *
	 * @param array $params Raw parameters.
	 * @return array
	 */
	private function normalize( $params ) {
		$clean = array();
		foreach ( (array) $params as $k => $v ) {
			// Only keep string/numeric values for key stability.
			if ( is_string( $v ) || is_numeric( $v ) ) {
				$clean[ $k ] = (string) $v;
			}
		}
		return $clean;
	}
}
