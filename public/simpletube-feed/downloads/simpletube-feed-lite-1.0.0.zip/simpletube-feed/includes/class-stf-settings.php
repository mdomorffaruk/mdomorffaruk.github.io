<?php
/**
 * Admin settings page.
 *
 * Provides a lightweight configuration UI with proper nonces, capability
 * checks, sanitization, and validation. No unsafe options or raw HTML.
 *
 * @package SimpleTubeFeed
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * STF_Settings
 */
class STF_Settings {

	/**
	 * Option name.
	 *
	 * @var string
	 */
	const OPTION = STF_OPTION_PREFIX . 'settings';

	/**
	 * Settings page slug.
	 *
	 * @var string
	 */
	const SLUG = 'simpletube-feed';

	/**
	 * Capability required to manage settings.
	 *
	 * @var string
	 */
	const CAP = 'manage_options';

	/**
	 * Nonce action.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'stf_save_settings';

	/**
	 * Constructor. Binds admin hooks.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_post_stf_save_settings', array( $this, 'save' ) );
		add_action( 'admin_post_stf_clear_cache', array( $this, 'clear_cache' ) );
	}

	/**
	 * Register the admin menu page.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_options_page(
			__( 'SimpleTube Feed', 'simpletube-feed' ),
			__( 'SimpleTube Feed', 'simpletube-feed' ),
			self::CAP,
			self::SLUG,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Default settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'channel_id' => '',
			'limit'      => 6,
			'layout'     => 'grid',
			'show_title' => 1,
			'show_date'  => 1,
			'new_tab'    => 1,
		);
	}

	/**
	 * Read the current settings merged over defaults.
	 *
	 * @return array
	 */
	public static function get_settings() {
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		return wp_parse_args( $stored, self::defaults() );
	}

	/**
	 * Sanitize submitted settings.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	protected function sanitize_settings( $input ) {
		$defaults = self::defaults();

		$channel = isset( $input['channel_id'] ) ? (string) $input['channel_id'] : '';
		$channel = preg_replace( '/[^A-Za-z0-9_\-]/', '', $channel );

		$layout = isset( $input['layout'] ) ? strtolower( (string) $input['layout'] ) : 'grid';
		$layout = in_array( $layout, array( 'grid', 'list' ), true ) ? $layout : 'grid';

		return array(
			'channel_id' => $channel,
			'limit'      => isset( $input['limit'] ) ? max( 1, min( 50, (int) $input['limit'] ) ) : (int) $defaults['limit'],
			'layout'     => $layout,
			'show_title' => empty( $input['show_title'] ) ? 0 : 1,
			'show_date'  => empty( $input['show_date'] ) ? 0 : 1,
			'new_tab'    => empty( $input['new_tab'] ) ? 0 : 1,
		);
	}

	/**
	 * Save handler.
	 *
	 * @return void
	 */
	public function save() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'simpletube-feed' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$settings = isset( $_POST['stf'] ) && is_array( $_POST['stf'] ) ? wp_unslash( $_POST['stf'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$settings = $this->sanitize_settings( $settings );

		update_option( self::OPTION, $settings, false );

		// Clear the feed cache so updated settings apply immediately.
		$cache = STF_Plugin::instance()->get_module( 'cache' );
		if ( $cache instanceof STF_Cache ) {
			$cache->clear_all();
		}

		wp_safe_redirect(
			add_query_arg( 'updated', '1', admin_url( 'options-general.php?page=' . self::SLUG ) )
		);
		exit;
	}

	/**
	 * Clear cache handler.
	 *
	 * @return void
	 */
	public function clear_cache() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'simpletube-feed' ) );
		}
		check_admin_referer( 'stf_clear_cache' );

		$cache = STF_Plugin::instance()->get_module( 'cache' );
		if ( $cache instanceof STF_Cache ) {
			$cache->clear_all();
		}

		wp_safe_redirect(
			add_query_arg( 'cleared', '1', admin_url( 'options-general.php?page=' . self::SLUG ) )
		);
		exit;
	}

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public function render_page() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}

		$settings = self::get_settings();

		// Field name prefix used by the save handler.
		$f = 'stf';

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'SimpleTube Feed Lite', 'simpletube-feed' ) . '</h1>';

		if ( isset( $_GET['updated'] ) && '1' === $_GET['updated'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'simpletube-feed' ) . '</p></div>';
		}
		if ( isset( $_GET['cleared'] ) && '1' === $_GET['cleared'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Feed cache cleared.', 'simpletube-feed' ) . '</p></div>';
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="stf_save_settings">';
		wp_nonce_field( self::NONCE_ACTION );
		echo '<table class="form-table" role="presentation">';

		// Channel.
		echo '<tr><th scope="row"><label for="stf-channel">' . esc_html__( 'YouTube Channel ID', 'simpletube-feed' ) . '</label></th>';
		echo '<td><input type="text" class="regular-text" id="stf-channel" name="' . esc_attr( $f ) . '[channel_id]" value="' . esc_attr( $settings['channel_id'] ) . '" maxlength="64">';
		echo '<p class="description">' . esc_html__( 'Find it in the channel URL: youtube.com/channel/CHANNEL_ID', 'simpletube-feed' ) . '</p></td></tr>';

		// Limit.
		echo '<tr><th scope="row"><label for="stf-limit">' . esc_html__( 'Number of videos', 'simpletube-feed' ) . '</label></th>';
		echo '<td><input type="number" min="1" max="50" id="stf-limit" name="' . esc_attr( $f ) . '[limit]" value="' . esc_attr( (string) $settings['limit'] ) . '"></td></tr>';

		// Layout.
		echo '<tr><th scope="row">' . esc_html__( 'Layout', 'simpletube-feed' ) . '</th><td><fieldset>';
		foreach ( array( 'grid' => __( 'Grid', 'simpletube-feed' ), 'list' => __( 'List', 'simpletube-feed' ) ) as $value => $label ) {
			echo '<label style="margin-right:1rem;"><input type="radio" name="' . esc_attr( $f ) . '[layout]" value="' . esc_attr( $value ) . '" ' . checked( $settings['layout'], $value, false ) . '> ' . esc_html( $label ) . '</label>';
		}
		echo '</fieldset></td></tr>';

		// Toggles.
		echo '<tr><th scope="row">' . esc_html__( 'Options', 'simpletube-feed' ) . '</th><td><fieldset>';
		echo $this->checkbox( $f, 'show_title', $settings['show_title'], __( 'Show video titles', 'simpletube-feed' ) );
		echo $this->checkbox( $f, 'show_date', $settings['show_date'], __( 'Show publish date', 'simpletube-feed' ) );
		echo $this->checkbox( $f, 'new_tab', $settings['new_tab'], __( 'Open videos in a new tab', 'simpletube-feed' ) );
		echo '</fieldset></td></tr>';

		echo '</table>';

		submit_button( __( 'Save Settings', 'simpletube-feed' ) );
		echo '</form>';

		// Usage + cache clear.
		echo '<hr>';
		echo '<h2>' . esc_html__( 'Usage', 'simpletube-feed' ) . '</h2>';
		echo '<p><code>[simpletube_feed channel="YOUR_CHANNEL_ID" limit="6"]</code></p>';
		echo '<p>' . esc_html__( 'Add the shortcode to any post, page, or widget. See the documentation for the full attribute list.', 'simpletube-feed' ) . '</p>';

		echo '<h2>' . esc_html__( 'Cache', 'simpletube-feed' ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline;">';
		echo '<input type="hidden" name="action" value="stf_clear_cache">';
		wp_nonce_field( 'stf_clear_cache' );
		echo '<p>' . esc_html__( 'Feeds are cached to keep your site fast. Clear the cache to fetch fresh data immediately.', 'simpletube-feed' ) . '</p>';
		submit_button( __( 'Clear Feed Cache', 'simpletube-feed' ), 'secondary', 'submit', false );
		echo '</form>';

		echo '</div>';
	}

	/**
	 * Render a labeled checkbox.
	 *
	 * @param string $prefix Form prefix.
	 * @param string $name   Field name.
	 * @param mixed  $value  Checkbox state.
	 * @param string $label  Label text.
	 * @return string
	 */
	protected function checkbox( $prefix, $name, $value, $label ) {
		return '<label style="display:block;margin-bottom:0.5rem;">'
			. '<input type="checkbox" name="' . esc_attr( $prefix ) . '[' . esc_attr( $name ) . ']" value="1" ' . checked( (int) $value, 1, false ) . '> '
			. esc_html( $label )
			. '</label>';
	}
}
