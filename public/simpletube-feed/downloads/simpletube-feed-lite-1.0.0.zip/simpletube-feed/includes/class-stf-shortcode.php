<?php
/**
 * Shortcode handler.
 *
 * Registers and renders the [simpletube_feed] shortcode.
 *
 * Example:
 *   [simpletube_feed channel="CHANNEL_ID" limit="6" layout="grid"]
 *
 * @package SimpleTubeFeed
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * STF_Shortcode
 */
class STF_Shortcode {

	/**
	 * Parser instance.
	 *
	 * @var STF_Feed_Parser
	 */
	protected $parser;

	/**
	 * Cache instance.
	 *
	 * @var STF_Cache
	 */
	protected $cache;

	/**
	 * Renderer instance.
	 *
	 * @var STF_Renderer
	 */
	protected $renderer;

	/**
	 * Constructor.
	 *
	 * @param STF_Feed_Parser $parser   Parser.
	 * @param STF_Cache       $cache    Cache.
	 * @param STF_Renderer    $renderer Renderer.
	 */
	public function __construct( STF_Feed_Parser $parser, STF_Cache $cache, STF_Renderer $renderer ) {
		$this->parser   = $parser;
		$this->cache    = $cache;
		$this->renderer = $renderer;

		add_shortcode( 'simpletube_feed', array( $this, 'run' ) );
	}

	/**
	 * Get the plugin default settings.
	 *
	 * @return array
	 */
	public function defaults() {
		$stored = get_option( STF_OPTION_PREFIX . 'settings', array() );
		$stored = is_array( $stored ) ? $stored : array();

		return wp_parse_args(
			$stored,
			array(
				'channel_id' => '',
				'limit'      => 6,
				'layout'     => 'grid',
				'show_title' => 1,
				'show_date'  => 1,
				'new_tab'    => 1,
			)
		);
	}

	/**
	 * Sanitize / normalize shortcode attributes.
	 *
	 * @param array $atts Raw attributes.
	 * @return array
	 */
	public function normalize_attributes( $atts ) {
		$defaults = $this->defaults();

		$atts = shortcode_atts(
			array(
				'channel'   => isset( $defaults['channel_id'] ) ? $defaults['channel_id'] : '',
				'limit'     => isset( $defaults['limit'] ) ? $defaults['limit'] : 6,
				'layout'    => isset( $defaults['layout'] ) ? $defaults['layout'] : 'grid',
				'show_title' => isset( $defaults['show_title'] ) ? $defaults['show_title'] : 1,
				'show_date'  => isset( $defaults['show_date'] ) ? $defaults['show_date'] : 1,
				'new_tab'    => isset( $defaults['new_tab'] ) ? $defaults['new_tab'] : 1,
				'heading'    => '',
				'cache'      => STF_Cache::DEFAULT_TTL,
			),
			$atts,
			'simpletube_feed'
		);

		// Channel: only allow chars that appear in real channel ids.
		$channel = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $atts['channel'] );

		return array(
			'channel'    => $channel,
			'limit'      => max( 1, min( 50, (int) $atts['limit'] ) ),
			'layout'     => in_array( strtolower( (string) $atts['layout'] ), array( 'grid', 'list' ), true ) ? strtolower( (string) $atts['layout'] ) : 'grid',
			'show_title' => (int) (bool) $atts['show_title'],
			'show_date'  => (int) (bool) $atts['show_date'],
			'new_tab'    => (int) (bool) $atts['new_tab'],
			'heading'    => sanitize_text_field( (string) $atts['heading'] ),
			'no_cache'   => ( 'false' === strtolower( (string) $atts['cache'] ) || '0' === (string) $atts['cache'] ),
			'cache_ttl'  => ctype_digit( (string) $atts['cache'] ) ? (int) $atts['cache'] : STF_Cache::DEFAULT_TTL,
		);
	}

	/**
	 * Shortcode callback.
	 *
	 * @param array|string $atts Attributes.
	 * @return string
	 */
	public function run( $atts ) {
		// Never trust raw attributes; normalize everything.
		if ( ! is_array( $atts ) ) {
			$atts = array();
		}
		$args = $this->normalize_attributes( $atts );

		return $this->renderer->render( $args );
	}
}
