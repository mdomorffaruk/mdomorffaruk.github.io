<?php
/**
 * YouTube channel feed fetcher and parser.
 *
 * Uses YouTube's official, publicly documented RSS feed for channels:
 *   https://www.youtube.com/feeds/videos.xml?channel_id={id}
 *
 * No API key is required for RSS mode. We never scrape YouTube HTML pages.
 * All remote data is validated and sanitized before it is stored or echoed.
 *
 * @package SimpleTubeFeed
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * STF_Feed_Parser
 */
class STF_Feed_Parser {

	/**
	 * Mapping of YouTube version to its RSS feed URL.
	 *
	 * @param string $channel_id Validated channel id.
	 * @return string|WP_Error URL on success, WP_Error on invalid id.
	 */
	protected function build_feed_url( $channel_id ) {
		$channel_id = trim( (string) $channel_id );

		// Channel ids are typically 24 chars, alphanumeric plus "-" and "_".
		if ( ! preg_match( '/^[A-Za-z0-9_\-]{6,64}$/', $channel_id ) ) {
			return new WP_Error(
				'stf_invalid_channel',
				__( 'Invalid YouTube channel id.', 'simpletube-feed' )
			);
		}

		// HTTPS only, fixed host, no user-controlled host.
		return 'https://www.youtube.com/feeds/videos.xml?channel_id=' . rawurlencode( $channel_id );
	}

	/**
	 * Fetch and parse a channel feed.
	 *
	 * @param string $channel_id Channel id.
	 * @param int    $limit      Max items to return.
	 * @return array|WP_Error Array of items or WP_Error on failure.
	 */
	public function fetch( $channel_id, $limit = 6 ) {
		$url = $this->build_feed_url( $channel_id );
		if ( is_wp_error( $url ) ) {
			return $url;
		}

		$args = array(
			'timeout'     => 10,
			'redirection' => 2,
			'user-agent'  => 'SimpleTubeFeed/' . STF_VERSION,
			// Do not follow redirects to arbitrary external hosts.
			'headers'     => array( 'Accept' => 'application/atom+xml, application/xml, text/xml' ),
		);

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error(
				'stf_http_error',
				sprintf(
					// translators: %d is the HTTP status code.
					__( 'YouTube returned HTTP %d.', 'simpletube-feed' ),
					$code
				)
			);
		}

		$body = wp_remote_retrieve_body( $response );
		if ( '' === $body ) {
			return new WP_Error( 'stf_empty_feed', __( 'The feed was empty.', 'simpletube-feed' ) );
		}

		return $this->parse( $body, $limit );
	}

	/**
	 * Parse an Atom feed body into a normalized array of items.
	 *
	 * @param string $body  Raw feed XML.
	 * @param int    $limit Max items.
	 * @return array|WP_Error
	 */
	public function parse( $body, $limit = 6 ) {
		$limit = max( 1, min( 50, (int) $limit ) );

		// Use libxml to prevent warnings and disable network/entity access.
		$prev = libxml_use_internal_errors( true );
		// Disable external entity loading to harden against XXE.
		$xml = simplexml_load_string( $body, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );

		if ( false === $xml ) {
			return new WP_Error( 'stf_bad_xml', __( 'The feed could not be parsed.', 'simpletube-feed' ) );
		}

		$items   = array();
		$entries = $xml->entry;

		foreach ( $entries as $entry ) {
			if ( count( $items ) >= $limit ) {
				break;
			}

			$item = $this->extract_entry( $entry );
			if ( null !== $item ) {
				$items[] = $item;
			}
		}

		return $items;
	}

	/**
	 * Extract and sanitize a single feed entry.
	 *
	 * @param SimpleXMLElement $entry Feed entry.
	 * @return array|null Sanitized item, or null if unusable.
	 */
	protected function extract_entry( $entry ) {
		$raw_title = isset( $entry->title ) ? (string) $entry->title : '';
		$title     = sanitize_text_field( $raw_title );
		if ( '' === $title ) {
			return null;
		}

		// Video id from <yt:videoId>.
		$video_id = '';
		$ns_yt    = $entry->children( 'http://www.youtube.com/xml/schemas/2015' );
		if ( isset( $ns_yt->videoId ) ) {
			$video_id = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $ns_yt->videoId );
		}
		if ( '' === $video_id ) {
			// Fallback: derive from link href query param if possible.
			$video_id = $this->video_id_from_link( isset( $entry->link ) ? (string) $entry->link : '' );
		}
		if ( '' === $video_id ) {
			return null;
		}

		// Primary link (first link element with rel=alternate).
		$link   = '';
		$links  = isset( $entry->link ) ? $entry->link : array();
		foreach ( $links as $l ) {
			$attrs = $l->attributes();
			if ( ! isset( $attrs['href'] ) ) {
				continue;
			}
			$href = esc_url_raw( (string) $attrs['href'] );
			if ( '' !== $href ) {
				$link = $href;
				break;
			}
		}
		if ( '' === $link ) {
			$link = esc_url_raw( $this->build_video_url( $video_id ) );
		}

		// Publish / updated date.
		$published = isset( $entry->published ) ? (string) $entry->published : ( isset( $entry->updated ) ? (string) $entry->updated : '' );
		$timestamp = strtotime( $published );
		$timestamp = ( false === $timestamp || $timestamp < 0 ) ? 0 : $timestamp;

		// Thumbnail + description from media group.
		$thumb       = '';
		$description = '';
		$media       = $entry->children( 'http://search.yahoo.com/mrss/' );
		if ( isset( $media->group ) ) {
			if ( isset( $media->group->thumbnail ) ) {
				$thumb_attrs = $media->group->thumbnail->attributes();
				if ( isset( $thumb_attrs['url'] ) ) {
					$candidate = esc_url_raw( (string) $thumb_attrs['url'] );
					if ( $this->is_yt_cdn_url( $candidate ) ) {
						$thumb = $candidate;
					}
				}
				// Fall back to a standard thumbnail URL from the video id.
				if ( '' === $thumb ) {
					$thumb = $this->build_thumbnail_url( $video_id );
				}
			}
			if ( isset( $media->group->description ) ) {
				$description = sanitize_text_field( (string) $media->group->description );
			}
		}

		return array(
			'title'       => $title,
			'video_id'    => $video_id,
			'link'        => $link,
			'thumbnail'   => $thumb,
			'date'        => $timestamp,
			'description' => $description,
		);
	}

	/**
	 * Build a watch URL from a validated video id.
	 *
	 * @param string $video_id Video id.
	 * @return string
	 */
	protected function build_video_url( $video_id ) {
		return 'https://www.youtube.com/watch?v=' . rawurlencode( $video_id );
	}

	/**
	 * Build a standard thumbnail URL.
	 *
	 * @param string $video_id Video id.
	 * @return string
	 */
	protected function build_thumbnail_url( $video_id ) {
		// i.ytimg.com is the documented thumbnail CDN.
		return 'https://i.ytimg.com/vi/' . rawurlencode( $video_id ) . '/hqdefault.jpg';
	}

	/**
	 * Ensure the thumbnail points only at YouTube's CDN.
	 *
	 * @param string $url Candidate URL.
	 * @return bool
	 */
	protected function is_yt_cdn_url( $url ) {
		$parsed = wp_parse_url( $url );
		if ( ! $parsed || empty( $parsed['host'] ) ) {
			return false;
		}
		$host = strtolower( $parsed['host'] );
		return 'i.ytimg.com' === $host || 'img.youtube.com' === $host;
	}

	/**
	 * Attempt to pull a video id out of a watch link.
	 *
	 * @param string $url Link URL.
	 * @return string
	 */
	protected function video_id_from_link( $url ) {
		$parsed = wp_parse_url( $url );
		if ( ! $parsed || empty( $parsed['query'] ) ) {
			return '';
		}
		parse_str( $parsed['query'], $query );
		if ( isset( $query['v'] ) ) {
			return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $query['v'] );
		}
		return '';
	}
}
