<?php
/**
 * Gutenberg block registration.
 *
 * Registers a dynamic block. The block renders server-side via the
 * shortcode renderer so no feed data ever reaches the frontend JS bundle.
 *
 * @package SimpleTubeFeed
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * STF_Block
 */
class STF_Block {

	/**
	 * Block name.
	 *
	 * @var string
	 */
	const BLOCK = 'simpletube/feed';

	/**
	 * Shortcode instance for server rendering.
	 *
	 * @var STF_Shortcode
	 */
	protected $shortcode;

	/**
	 * Constructor.
	 *
	 * @param STF_Shortcode $shortcode Shortcode instance.
	 */
	public function __construct( STF_Shortcode $shortcode ) {
		$this->shortcode = $shortcode;
		add_action( 'init', array( $this, 'register' ) );
	}

	/**
	 * Register the block.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		wp_register_script(
			'stf-block-editor',
			STF_PLUGIN_URL . 'assets/js/stf-block.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ),
			STF_VERSION,
			true
		);

		register_block_type(
			'simpletube/feed',
			array(
				'api_version'     => 2,
				'attributes'      => array(
					'channel' => array(
						'type'    => 'string',
						'default' => '',
					),
					'limit'   => array(
						'type'    => 'number',
						'default' => 6,
					),
					'layout'  => array(
						'type'    => 'string',
						'default' => 'grid',
					),
					'heading' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
				'render_callback' => array( $this, 'render' ),
				'editor_script'   => 'stf-block-editor',
			)
		);
	}

	/**
	 * Server render callback.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render( $attributes ) {
		$attributes = is_array( $attributes ) ? $attributes : array();
		return $this->shortcode->run( $attributes );
	}
}
