<?php
/**
 * Plugin Name:       SimpleTube Feed Lite
 * Plugin URI:        https://mdomorffaruk.github.io/simpletube/
 * Description:       Display a clean, lightweight YouTube channel feed on your WordPress site using the official public RSS feed. No API key required. Fast, simple, and bloat-free.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Mohammad Omor Faruk
 * Author URI:        https://mdomorffaruk.github.io/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       simpletube-feed
 * Domain Path:       /languages
 *
 * @package SimpleTubeFeed
 */

// Block direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'STF_VERSION', '1.0.0' );
define( 'STF_PLUGIN_FILE', __FILE__ );
define( 'STF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'STF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Options / keys prefix. Unique to this plugin only.
define( 'STF_OPTION_PREFIX', 'stf_' );
define( 'STF_CACHE_GROUP', 'stf_feed' );

/**
 * Core registry / loader.
 *
 * Loads the shared internal classes used by both Lite and (via the
 * Pro companion plugin) the extended features. All classes are namespaced
 * under the Stf_ prefix to avoid global namespace pollution.
 */
final class STF_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var STF_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Holds the module instances.
	 *
	 * @var array
	 */
	private $modules = array();

	/**
	 * Get the singleton.
	 *
	 * @return STF_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Binds hooks.
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	/**
	 * Include internal class files.
	 *
	 * @return void
	 */
	public function includes() {
		$dir = STF_PLUGIN_DIR . 'includes/';

		require_once $dir . 'class-stf-cache.php';
		require_once $dir . 'class-stf-feed-parser.php';
		require_once $dir . 'class-stf-renderer.php';
		require_once $dir . 'class-stf-shortcode.php';
		require_once $dir . 'class-stf-settings.php';
		require_once $dir . 'class-stf-block.php';
	}

	/**
	 * Boot the plugin after all plugins are loaded.
	 *
	 * @return void
	 */
	public function init() {
		$this->includes();

		// Abort if WordPress core is missing a required function (defensive).
		if ( ! function_exists( 'esc_html' ) ) {
			return;
		}

		$this->modules['cache']    = new STF_Cache();
		$this->modules['parser']   = new STF_Feed_Parser();
		$this->modules['renderer'] = new STF_Renderer( $this->modules['cache'] );
		$this->modules['shortcode'] = new STF_Shortcode( $this->modules['parser'], $this->modules['cache'], $this->modules['renderer'] );
		$this->modules['settings'] = new STF_Settings();

		if ( class_exists( 'WP_Block_Type_Registry' ) ) {
			$this->modules['block'] = new STF_Block( $this->modules['shortcode'] );
		}
	}

	/**
	 * Get a loaded module.
	 *
	 * @param string $key Module key.
	 * @return object|null
	 */
	public function get_module( $key ) {
		return isset( $this->modules[ $key ] ) ? $this->modules[ $key ] : null;
	}

	/**
	 * Activation hook: set default options, flush caches.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		$defaults = array(
			'channel_id' => '',
			'limit'      => 6,
			'layout'     => 'grid',
			'show_title' => 1,
			'show_date'  => 1,
			'new_tab'    => 1,
		);
		$stored   = get_option( STF_OPTION_PREFIX . 'settings', array() );
		$settings = array_merge( $defaults, is_array( $stored ) ? $stored : array() );

		update_option( STF_OPTION_PREFIX . 'settings', $settings );

		flush_rewrite_rules();
	}

	/**
	 * Deactivation hook: clear transient caches only (keep settings).
	 *
	 * @return void
	 */
	public static function deactivate() {
		if ( function_exists( 'delete_transient' ) ) {
			// Clear the transient cache using a WP API call if available.
			$cache = STF_Plugin::instance()->get_module( 'cache' );
			if ( $cache instanceof STF_Cache ) {
				$cache->clear_all();
			}
		}
		flush_rewrite_rules();
	}
}

register_activation_hook( __FILE__, array( 'STF_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'STF_Plugin', 'deactivate' ) );

STF_Plugin::instance();
